namespace Rutana.API.IAM.Domain.Model.Queries;

public record GetUserByUsernameQuery(string Username);