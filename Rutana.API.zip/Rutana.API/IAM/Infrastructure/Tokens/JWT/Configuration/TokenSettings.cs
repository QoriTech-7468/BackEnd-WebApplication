namespace Rutana.API.IAM.Infrastructure.Tokens.JWT.Configuration;

public class TokenSettings
{
    public string Secret { get; set; } = string.Empty; 
}